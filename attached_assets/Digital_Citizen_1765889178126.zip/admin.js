import { db, appId, state, cityOptions, renderApp } from './shared.js';
import { setDoc, doc, serverTimestamp, addDoc, collection, updateDoc, deleteDoc, getDocs, orderBy, query, limit } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
import { forumData } from './forum.js';
import { eventsData } from './events.js';

// --- STATE ---
let adminJobsList = [];
let adminUsersList = [];
let editingJob = null;
let editingEventAdmin = null;
let editingUser = null;
let userLoadError = null;

// --- USER MANAGEMENT ACTIONS ---

export async function loadAdminUsers() {
    userLoadError = null;
    try {
        // FETCH FROM DIRECTORY (Avoids Permission Error)
        const q = query(collection(db, 'artifacts', appId, 'public', 'data', 'users_directory'));
        const snap = await getDocs(q);

        adminUsersList = snap.docs.map(d => ({
            id: d.id,
            ...d.data()
        }));

    } catch (error) {
        console.error("Admin User Load Error:", error);
        userLoadError = "Could not load users. Ensure users have signed up with the new system.";
        adminUsersList = [];
    }
    renderApp();
}

export function setEditingUser(uid) {
    editingUser = adminUsersList.find(u => u.id === uid);
    window.scrollTo(0, 0);
    renderApp();
}

export function clearEditingUser() {
    editingUser = null;
    renderApp();
}

export async function handleAdminUpdateUser(e, uid) {
    e.preventDefault();
    const userObj = adminUsersList.find(u => u.id === uid);
    if (!userObj) return;

    const updates = {
        name: e.target.name.value,
        city: e.target.city.value,
        role: e.target.role.value,
    };

    try {
        // 1. Update Private Profile
        await updateDoc(doc(db, 'artifacts', appId, 'users', uid, 'profile', 'main'), updates);

        // 2. Update Directory Listing
        await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'users_directory', uid), updates);

        editingUser = null;
        state.adminMessage = "User Updated Successfully";
        await loadAdminUsers();
    } catch (error) {
        console.error(error);
        state.adminMessage = "Error updating user.";
    }
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 2000);
}

export async function handleToggleVerifyUser(uid) {
    const userObj = adminUsersList.find(u => u.id === uid);
    if (!userObj) return;

    const newStatus = !userObj.isVerified;
    try {
        // 1. Update Private Profile
        await updateDoc(doc(db, 'artifacts', appId, 'users', uid, 'profile', 'main'), { isVerified: newStatus });

        // 2. Update Directory Listing
        await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'users_directory', uid), { isVerified: newStatus });

        state.adminMessage = `User ${newStatus ? 'Verified' : 'Unverified'}`;
        userObj.isVerified = newStatus; // Optimistic update
    } catch (error) {
        state.adminMessage = "Error changing verification status.";
    }
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 2000);
}

// --- EXISTING ACTIONS (Jobs/Events) ---

export async function loadAdminJobs() {
    try {
        const q = query(collection(db, 'artifacts', appId, 'public', 'data', 'jobs'), orderBy('postedAt', 'desc'), limit(50));
        const snap = await getDocs(q);
        adminJobsList = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        renderApp();
    } catch (e) {
        console.log("Job load error", e);
    }
}

export function setEditingJob(id) {
    editingJob = adminJobsList.find(job => job.id === id);
    window.scrollTo(0, 0);
    renderApp();
}

export function clearEditingJob() {
    editingJob = null;
    renderApp();
}

export async function handleAdminEditJob(e, id) {
    e.preventDefault();
    if (!id || !editingJob) return;
    try {
        await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'jobs', id), {
            title: e.target.title.value,
            location: e.target.location.value,
            sector: e.target.sector.value,
            type: e.target.type.value,
            salary: e.target.salary.value,
            contact: e.target.contact.value,
            description: e.target.description.value,
        });
        editingJob = null;
        state.adminMessage = "Job Updated";
        loadAdminJobs();
    } catch (error) { state.adminMessage = "Error updating job."; }
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 2000);
}

export async function handleAdminAddJob(e) {
    e.preventDefault();
    await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'jobs'), {
        title: e.target.title.value,
        location: e.target.location.value,
        sector: e.target.sector.value,
        type: e.target.type.value,
        salary: e.target.salary.value,
        contact: e.target.contact.value,
        description: e.target.description.value,
        postedAt: serverTimestamp(),
        source: 'Admin'
    });
    state.adminMessage = "Job Added";
    e.target.reset();
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 2000);
}

export async function handleAdminDeleteJob(id) {
    if (!confirm("Delete this job?")) return;
    await deleteDoc(doc(db, 'artifacts', appId, 'public', 'data', 'jobs', id));
    state.adminMessage = "Job Deleted";
    loadAdminJobs();
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 2000);
}

// Event Actions
export function setEditingEventAdmin(id) {
    editingEventAdmin = eventsData.all.find(e => e.id === id);
    window.scrollTo(0, 0);
    renderApp();
}

export function clearEditingEventAdmin() {
    editingEventAdmin = null;
    renderApp();
}

export async function handleAdminAddEvent(e) {
    e.preventDefault();
    const isFree = e.target.isFree.value === 'true';
    await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'events'), {
        title: e.target.title.value,
        details: e.target.details.value,
        city: e.target.city.value,
        date: e.target.date.value,
        isFree: isFree,
        ticketPrice: isFree ? 'Free' : e.target.ticketPrice.value,
        paymentLink: e.target.paymentLink.value,
        maxAttendees: parseInt(e.target.maxAttendees.value) || 0,
        currentAttendees: 0,
        postedByUid: state.currentUser.uid,
        postedByName: 'Admin',
        postedAt: new Date().toISOString()
    });
    state.adminMessage = "Event Added";
    e.target.reset();
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 3000);
}

export async function handleAdminEditEvent(e, id) {
    e.preventDefault();
    const isFree = e.target.isFree.value === 'true';
    try {
        await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'events', id), {
            title: e.target.title.value,
            details: e.target.details.value,
            city: e.target.city.value,
            date: e.target.date.value,
            isFree: isFree,
            ticketPrice: isFree ? 'Free' : e.target.ticketPrice.value,
            paymentLink: e.target.paymentLink.value,
            maxAttendees: parseInt(e.target.maxAttendees.value) || 0,
            currentAttendees: parseInt(e.target.currentAttendees.value) || 0,
        });
        editingEventAdmin = null;
        state.adminMessage = "Event Updated";
        renderApp();
    } catch (error) { state.adminMessage = "Error updating event."; renderApp(); }
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 3000);
}

export async function handleAdminDeleteEvent(id) {
    if (!confirm("Delete event?")) return;
    try {
        await deleteDoc(doc(db, 'artifacts', appId, 'public', 'data', 'events', id));
        state.adminMessage = "Event Deleted";
        renderApp();
    } catch (error) { state.adminMessage = "Error deleting event."; renderApp(); }
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 3000);
}

export async function handleAdminStatusUpdate(e) {
    e.preventDefault();
    await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'civic_status', e.target.city.value), {
        status: e.target.status.value,
        traffic_alert: e.target.traffic.value,
        updatedAt: serverTimestamp()
    });
    state.adminMessage = "Status Updated";
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 2000);
}

export async function handleReinstatePost(postId) {
    await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'forum_posts', postId), { flagged: false });
    state.adminMessage = "Post Reinstated";
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 2000);
}

export async function handleDeletePost(postId) {
    await deleteDoc(doc(db, 'artifacts', appId, 'public', 'data', 'forum_posts', postId));
    state.adminMessage = "Post Deleted";
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 2000);
}

// --- RENDER HELPERS ---

function renderAdminEventForm(event = {}) {
    const isEditing = !!event.id;
    const action = isEditing ? `handleAdminEditEvent(event, '${event.id}')` : `handleAdminAddEvent(event)`;
    const isFree = event.isFree === undefined ? true : event.isFree;

    return `
        <div class="bg-white p-6 rounded-xl shadow-lg mb-6 border ${isEditing ? 'border-yellow-400' : 'border-green-400'}">
            <h2 class="font-bold text-xl mb-4 border-b pb-2 ${isEditing ? 'text-yellow-700' : 'text-green-700'}">${isEditing ? `Editing Event: ${event.title}` : 'Post New Event'}</h2>
            <form onsubmit="${action}" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input name="title" placeholder="Event Title" value="${event.title || ''}" class="w-full p-2 border rounded text-sm md:col-span-2" required>
                <textarea name="details" placeholder="Description" class="w-full p-2 border rounded text-sm md:col-span-2" rows="4" required>${event.details || ''}</textarea>
                <select name="city" class="w-full p-2 border rounded text-sm">${cityOptions.replace(`value="${event.city}"`, `value="${event.city}" selected`)}</select>
                <input name="date" type="date" value="${event.date?.substring(0, 10) || ''}" class="w-full p-2 border rounded text-sm" required>
                <div class="flex items-center gap-4 p-2 border rounded bg-gray-50 md:col-span-2">
                    <label class="font-bold text-sm">Ticket Type:</label>
                    <input type="radio" name="isFree" value="true" id="admin-free" ${isFree ? 'checked' : ''} onchange="document.getElementById('admin-price').classList.add('hidden');document.getElementById('admin-link').classList.add('hidden');"> <label for="admin-free" class="mr-4">Free</label>
                    <input type="radio" name="isFree" value="false" id="admin-paid" ${!isFree ? 'checked' : ''} onchange="document.getElementById('admin-price').classList.remove('hidden');document.getElementById('admin-link').classList.remove('hidden');"> <label for="admin-paid">Paid</label>
                </div>
                <input id="admin-price" name="ticketPrice" placeholder="Price" value="${event.ticketPrice || ''}" class="w-full p-2 border rounded text-sm ${isFree ? 'hidden' : ''}">
                <input name="maxAttendees" type="number" placeholder="Max Attendees" value="${event.maxAttendees || 0}" class="w-full p-2 border rounded text-sm">
                <input id="admin-link" name="paymentLink" placeholder="Payment Link" value="${event.paymentLink || ''}" class="w-full p-2 border rounded text-sm md:col-span-2 ${isFree ? 'hidden' : ''}">
                ${isEditing ? `<input name="currentAttendees" type="number" placeholder="Current Attendees Override" value="${event.currentAttendees || 0}" class="w-full p-2 border rounded text-sm">` : ''}
                <div class="md:col-span-2 flex gap-3">
                    <button type="submit" class="w-full bg-green-600 text-white py-2 rounded font-bold hover:bg-green-700">${isEditing ? 'Save' : 'Post'}</button>
                    ${isEditing ? `<button type="button" onclick="clearEditingEventAdmin()" class="w-1/3 bg-gray-300 text-gray-800 py-2 rounded hover:bg-gray-400">Cancel</button>` : ''}
                </div>
            </form>
        </div>`;
}

function renderUserEditForm(user) {
    return `
    <div class="bg-white p-6 rounded-xl shadow-lg mb-6 border border-purple-500">
        <h2 class="font-bold text-xl mb-4 text-purple-700">Edit User: ${user.name}</h2>
        <form onsubmit="handleAdminUpdateUser(event, '${user.id}')" class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><label class="text-xs font-bold">Full Name</label><input name="name" value="${user.name}" class="w-full p-2 border rounded text-sm"></div>
            <div><label class="text-xs font-bold">City</label><select name="city" class="w-full p-2 border rounded text-sm">${cityOptions.replace(`value="${user.city}"`, `value="${user.city}" selected`)}</select></div>
            <div><label class="text-xs font-bold">Role</label><select name="role" class="w-full p-2 border rounded text-sm">
                <option value="user" ${user.role === 'user' ? 'selected' : ''}>User</option>
                <option value="admin" ${user.role === 'admin' ? 'selected' : ''}>Admin</option>
            </select></div>
            <div><label class="text-xs font-bold text-gray-400">Email (Read Only)</label><input value="${user.email}" disabled class="w-full p-2 border rounded text-sm bg-gray-100 text-gray-500"></div>
            <div class="md:col-span-2 flex gap-3">
                <button type="submit" class="w-full bg-purple-600 text-white py-2 rounded font-bold hover:bg-purple-700">Update User</button>
                <button type="button" onclick="clearEditingUser()" class="w-1/3 bg-gray-300 text-gray-800 py-2 rounded hover:bg-gray-400">Cancel</button>
            </div>
        </form>
    </div>`;
}

// --- RENDER ADMIN ---
export function renderAdmin() {
    if (adminJobsList.length === 0) loadAdminJobs();

    const flaggedPosts = forumData.posts.filter(p => p.flagged);

    return `
    <div class="bg-gray-100 h-full p-4 overflow-y-auto pb-safe">
        <div class="max-w-4xl mx-auto">
            <div class="flex justify-between mb-6">
                <h1 class="text-2xl font-bold">Admin Panel</h1>
                <button onclick="setAppView('dashboard')" class="text-red-600">Exit</button>
            </div>
            ${state.adminMessage ? `<div class="bg-green-100 text-green-700 p-2 rounded mb-4 fade-in">${state.adminMessage}</div>` : ''}

            <div class="bg-white p-6 rounded-xl shadow-sm mb-6 border border-purple-200">
                <div class="flex justify-between items-center mb-4 border-b pb-2">
                    <h2 class="font-bold text-lg text-purple-900">User Management</h2>
                    <button onclick="loadAdminUsers()" class="text-sm text-purple-600"><i class="fas fa-sync"></i> Load/Refresh Users</button>
                </div>
                
                ${userLoadError ? `<div class="bg-red-100 text-red-700 p-3 rounded mb-4 text-xs">${userLoadError}</div>` : ''}
                ${editingUser ? renderUserEditForm(editingUser) : ''}

                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm">
                        <thead>
                            <tr class="bg-gray-50 border-b"><th class="p-2">Name</th><th class="p-2">Email</th><th class="p-2">City</th><th class="p-2">Status</th><th class="p-2">Actions</th></tr>
                        </thead>
                        <tbody>
                            ${adminUsersList.length === 0 && !userLoadError ? '<tr><td colspan="5" class="p-4 text-center text-gray-500">Click "Load Users" to view registered accounts.</td></tr>' :
            adminUsersList.map(u => `
                                <tr class="border-b hover:bg-gray-50">
                                    <td class="p-2 font-bold">${u.name}</td>
                                    <td class="p-2 text-gray-600">${u.email}</td>
                                    <td class="p-2">${u.city}</td>
                                    <td class="p-2">
                                        ${u.role === 'admin' ? '<span class="bg-red-100 text-red-700 px-2 py-0.5 rounded text-xs font-bold">Admin</span>' : ''}
                                        ${u.isVerified ? '<span class="bg-green-100 text-green-700 px-2 py-0.5 rounded text-xs font-bold">Verified</span>' : '<span class="text-gray-400 text-xs">Unverified</span>'}
                                    </td>
                                    <td class="p-2 flex gap-2">
                                        <button onclick="setEditingUser('${u.id}')" class="text-blue-600 hover:underline">Edit</button>
                                        <button onclick="handleToggleVerifyUser('${u.id}')" class="text-xs border px-2 py-1 rounded ${u.isVerified ? 'border-red-300 text-red-600 hover:bg-red-50' : 'border-green-300 text-green-600 hover:bg-green-50'}">
                                            ${u.isVerified ? 'Unverify' : 'Verify'}
                                        </button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-sm mb-6 border border-green-400">
                <h2 class="font-bold text-lg mb-4 text-green-700">Event Management (CRUD)</h2>
                ${renderAdminEventForm(editingEventAdmin || {})}
                <div class="mt-6 border-t pt-4">
                    <h3 class="font-bold text-lg mb-3">All Events (${eventsData.all.length})</h3>
                    <div class="h-64 overflow-y-auto space-y-2 border rounded p-2 bg-gray-50">
                        ${eventsData.all.map(event => `
                            <div class="bg-white p-2 rounded border flex justify-between items-center text-sm">
                                <div><span class="font-bold">${event.title}</span> <span class="text-gray-500">(${event.city})</span>
                                    <div class="text-xs text-gray-400">Date: ${event.date} | Attending: ${event.currentAttendees}/${event.maxAttendees || '∞'}</div>
                                </div>
                                <div class="flex gap-2">
                                    <button onclick="setEditingEventAdmin('${event.id}')" class="bg-yellow-100 text-yellow-700 px-3 py-1 rounded text-xs hover:bg-yellow-200 font-bold">Edit</button>
                                    <button onclick="handleAdminDeleteEvent('${event.id}')" class="text-red-600 hover:text-red-800 px-2"><i class="fas fa-trash"></i></button>
                                </div>
                            </div>`).join('')}
                    </div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-sm mb-6">
                <div class="flex justify-between items-center mb-4 border-b pb-2"><h2 class="font-bold text-lg text-blue-900">Manage Jobs</h2><button onclick="loadAdminJobs()" class="text-sm text-blue-600"><i class="fas fa-sync"></i> Refresh</button></div>
                <div class="h-64 overflow-y-auto space-y-2 border rounded p-2 bg-gray-50">
                    ${adminJobsList.map(job => `
                        <div class="bg-white p-2 rounded border flex justify-between items-center text-sm">
                            <div><span class="font-bold">${job.title}</span> <span class="text-gray-500 text-xs">(${job.source})</span><div class="text-xs text-gray-400">${job.location} - Posted by: ${job.postedBy || 'System'}</div></div>
                            <div class="flex gap-2">
                                <button onclick="setEditingJob('${job.id}')" class="bg-blue-100 text-blue-600 px-3 py-1 rounded text-xs hover:bg-blue-200 font-bold">Edit</button>
                                <button onclick="handleAdminDeleteJob('${job.id}')" class="text-red-600 hover:text-red-800 px-2"><i class="fas fa-trash"></i></button>
                            </div>
                        </div>`).join('')}
                </div>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-sm mb-6 border border-red-200">
                <h2 class="font-bold text-lg mb-4 text-red-600">Forum Moderation</h2>
                ${flaggedPosts.length === 0 ? '<p class="text-gray-500">No flagged posts.</p>' : flaggedPosts.map(p => `<div class="border p-3 rounded mb-2 flex justify-between items-center bg-red-50"><div><p class="text-sm font-bold">${p.author}: ${p.content}</p><p class="text-xs text-gray-500">Flagged by user</p></div><div class="flex gap-2"><button onclick="handleReinstatePost('${p.id}')" class="bg-green-600 text-white px-3 py-1 rounded text-xs hover:bg-green-700">Reinstate</button><button onclick="handleDeletePost('${p.id}')" class="bg-red-600 text-white px-3 py-1 rounded text-xs hover:bg-red-700">Delete</button></div></div>`).join('')}
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div class="bg-white p-6 rounded-xl shadow-sm">
                    <h2 class="font-bold text-lg mb-4 border-b pb-2">Update Civic Status</h2>
                    <form onsubmit="handleAdminStatusUpdate(event)" class="space-y-3">
                        <select name="city" class="w-full p-2 border rounded text-sm">${cityOptions}</select>
                        <select name="status" class="w-full p-2 border rounded text-sm"><option>Safe</option><option>Alert</option><option>Danger</option></select>
                        <textarea name="traffic" placeholder="Status Message..." class="w-full p-2 border rounded text-sm"></textarea>
                        <button class="w-full bg-red-600 text-white py-2 rounded hover:bg-red-700">Update</button>
                    </form>
                </div>
                <div class="bg-white p-6 rounded-xl shadow-sm lg:col-span-2">
                    <h2 class="font-bold text-lg mb-4 border-b pb-2">Post New Job</h2>
                    <form onsubmit="handleAdminAddJob(event)" class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <input name="title" placeholder="Job Title" class="w-full p-2 border rounded text-sm" required>
                        <select name="location" class="w-full p-2 border rounded text-sm"><option>Lagos</option><option>Abuja (FCT)</option><option>Port Harcourt (Rivers)</option><option>Remote</option></select>
                        <input name="sector" placeholder="Sector" class="w-full p-2 border rounded text-sm" required>
                        <select name="type" class="w-full p-2 border rounded text-sm"><option>Full-time</option><option>Part-time</option><option>Contract</option></select>
                        <input name="salary" placeholder="Salary" class="w-full p-2 border rounded text-sm">
                        <input name="contact" placeholder="Email/Link" class="w-full p-2 border rounded text-sm md:col-span-2" required>
                        <textarea name="description" placeholder="Description" class="w-full p-2 border rounded text-sm md:col-span-2" rows="3"></textarea>
                        <button class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 md:col-span-2">Post Job</button>
                    </form>
                </div>
            </div>
        </div>
    </div>`;
}