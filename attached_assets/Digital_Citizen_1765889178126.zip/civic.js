import { db, appId, state, renderApp, GEMINI_API_KEY } from './shared.js';
import { doc, onSnapshot, setDoc, getDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

// --- STATE ---
export const civicData = {
    status: null, // { status, traffic_alert, updatedAt }
    trafficData: null,
    isTrafficLoading: false
};

// --- LISTENERS ---
export function setupCivicListener() {
    const city = state.userProfile?.city || 'Lagos';
    const unsub = onSnapshot(doc(db, 'artifacts', appId, 'public', 'data', 'civic_status', city), (doc) => {
        civicData.status = doc.exists() ? doc.data() : { status: 'Unknown', traffic_alert: 'Traffic data loading...' };
        renderApp();
    });
    state.unsubscribers.push(unsub);
}

export async function seedCityData(city) {
    try {
        const ref = doc(db, 'artifacts', appId, 'public', 'data', 'civic_status', city);
        if (!(await getDoc(ref)).exists()) {
            await setDoc(ref, { status: 'Safe', traffic_alert: `Traffic is flowing normally in ${city}.`, updatedAt: serverTimestamp() });
        }
    } catch (e) { }
}

// --- ACTIONS ---
export async function fetchTrafficUpdate() {
    const city = state.userProfile?.city || 'Lagos';
    civicData.isTrafficLoading = true;
    renderApp();

    const textPrompt = `Search for the current live traffic situation in ${city}, Nigeria.
    Summarize the overall condition in one short sentence.
    Then, list the major congested roads/areas found under three specific labels:
    1. HEAVY_TRAFFIC: Streets with severe congestion or heavily reduced speed.
    2. MODERATE_TRAFFIC: Streets with increasing congestion or reduced speed.
    3. LIGHT_TRAFFIC: Streets with normal traffic flow or light congestion.

    Format your response EXACTLY and ONLY like this, using '||' as a separator:
    SUMMARY: [Insert Summary Here] || HEAVY_TRAFFIC: [Road 1, Road 2, ...] || MODERATE_TRAFFIC: [Road 3, Road 4, ...] || LIGHT_TRAFFIC: [Road 5, Road 6, ...]`;

    try {
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{ parts: [{ text: textPrompt }] }],
                tools: [{ googleSearchRetrieval: {} }]
            })
        });

        const data = await response.json();
        let summary = "Unable to parse live traffic summary.";
        let heavyTraffic = [];
        let moderateTraffic = [];
        let lightTraffic = [];

        const cleanList = (text, label) => {
            const listText = text.replace(label, '').trim();
            if (listText.toLowerCase().includes("none") || listText.length === 0 || listText.includes("No specific")) {
                return [];
            }
            return listText.split(',').map(s => s.trim()).filter(s => s.length > 0);
        };

        if (data.candidates && data.candidates[0].content.parts[0].text) {
            const rawText = data.candidates[0].content.parts[0].text;
            const parts = rawText.split('||').map(p => p.trim());

            if (parts.length >= 4) {
                if (parts[0].startsWith('SUMMARY:')) { summary = parts[0].replace('SUMMARY:', '').trim(); }
                if (parts[1].startsWith('HEAVY_TRAFFIC:')) { heavyTraffic = cleanList(parts[1], 'HEAVY_TRAFFIC:'); }
                if (parts[2].startsWith('MODERATE_TRAFFIC:')) { moderateTraffic = cleanList(parts[2], 'MODERATE_TRAFFIC:'); }
                if (parts[3].startsWith('LIGHT_TRAFFIC:')) { lightTraffic = cleanList(parts[3], 'LIGHT_TRAFFIC:'); }
            }

            civicData.trafficData = { summary, heavy: heavyTraffic, moderate: moderateTraffic, light: lightTraffic };
        } else {
            throw new Error("No candidate returned from AI");
        }
    } catch (error) {
        console.error("Traffic Error:", error);
        civicData.trafficData = {
            summary: "Unable to retrieve live data at this moment.",
            heavy: [], moderate: [], light: []
        };
    }

    civicData.isTrafficLoading = false;
    renderApp();
}

// --- RENDER ---
export function renderCivicCenter() {
    const city = state.userProfile?.city || 'Unknown';
    const statusText = civicData.status?.status || 'Unknown';
    let color = statusText === 'Safe' ? 'green' : statusText === 'Alert' ? 'yellow' : 'red';

    return `
    <div class="bg-gray-100 h-full flex flex-col overflow-hidden pb-safe">
        <div class="bg-white p-4 shadow-sm flex items-center gap-4 z-10">
            <button onclick="setAppView('dashboard')" class="text-gray-600"><i class="fas fa-arrow-left"></i> Back</button>
            <h1 class="font-bold text-xl">Civic Center: ${city}</h1>
        </div>
        <div class="flex-grow overflow-y-auto p-6 space-y-6">

            <div class="bg-white rounded-2xl shadow-lg p-8 text-center border-t-8 border-${color}-500">
                <div class="uppercase text-xs font-bold tracking-widest text-gray-400 mb-2">Current Security Status</div>
                <div class="text-4xl font-black text-${color}-600 mb-4 uppercase">${statusText}</div>
                <p class="text-lg text-gray-700">${civicData.status?.traffic_alert || 'No specific alerts.'}</p>
                <div class="mt-6 text-xs text-gray-400">Last Updated: ${civicData.status?.updatedAt ? new Date(civicData.status.updatedAt.toDate()).toLocaleString() : 'Recently'}</div>
            </div>

            <div class="bg-white rounded-xl shadow-sm p-6">
                <h3 class="font-bold text-lg mb-4">Emergency Contacts</h3>
                <div class="grid gap-3">
                    <div class="flex justify-between p-3 bg-gray-50 rounded-lg items-center">
                        <span class="font-bold text-gray-700">Police Control Room</span>
                        <a href="tel:112" class="bg-blue-100 text-blue-700 px-3 py-1 rounded font-bold">112</a>
                    </div>
                    <div class="flex justify-between p-3 bg-gray-50 rounded-lg items-center">
                        <span class="font-bold text-gray-700">Fire Service</span>
                        <a href="tel:112" class="bg-red-100 text-red-700 px-3 py-1 rounded font-bold">112</a>
                    </div>
                    <div class="flex justify-between p-3 bg-gray-50 rounded-lg items-center">
                        <span class="font-bold text-gray-700">Ambulance</span>
                        <a href="tel:112" class="bg-green-100 text-green-700 px-3 py-1 rounded font-bold">112</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
    `;
}