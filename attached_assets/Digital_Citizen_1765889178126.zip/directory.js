import { state, MOCK_DIRECTORY } from './shared.js';

export function renderDirectory() {
    const city = state.userProfile?.city || 'Unknown';
    let listings = MOCK_DIRECTORY[city] || [
        { name: `NBA ${city} Branch`, type: "Legal Aid", contact: "Unavailable" },
        { name: `${city} General Hospital`, type: "Health", contact: "Unavailable" }
    ];
    return `
    <div class="bg-gray-100 h-full p-4 overflow-y-auto pb-safe">
        <div class="max-w-4xl mx-auto">
            <div class="flex justify-between mb-6">
                <h1 class="text-2xl font-bold">Directory: ${city}</h1>
                <button onclick="setAppView('dashboard')" class="text-blue-600">Back</button>
            </div>
            <div class="grid gap-4">
                ${listings.map(i => `
                                <div class="bg-white p-4 rounded shadow flex justify-between items-center">
                                    <div>
                                        <b class="text-lg">${i.name}</b><br>
                                        <span class="text-xs bg-gray-100 text-gray-600 p-1 rounded uppercase font-bold">${i.type}</span>
                                    </div>
                                    <a href="tel:${i.contact}" class="bg-green-100 text-green-700 px-4 py-2 rounded font-bold hover:bg-green-200">
                                        <i class="fas fa-phone-alt mr-2"></i> Call
                                    </a>
                                </div>`).join('')}
            </div>
        </div>
    </div>`;
}