import { db, appId, state, renderApp, cityOptions } from './shared.js';
import { collection, query, onSnapshot, orderBy, doc, addDoc, updateDoc, deleteDoc } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

// --- STATE ---
export const eventsData = {
    all: [],
    localEvents: [],
    editingEvent: null,
};

// --- LISTENERS ---
export function setupEventsListener() {
    const allQuery = query(collection(db, 'artifacts', appId, 'public', 'data', 'events'), orderBy('date', 'desc'));
    const unsubAll = onSnapshot(allQuery, (snap) => {
        eventsData.all = snap.docs.map(d => ({
            id: d.id,
            ...d.data(),
            currentAttendees: d.data().currentAttendees || 0,
            maxAttendees: d.data().maxAttendees || 0,
            isSpaceFull: (d.data().maxAttendees > 0) && ((d.data().currentAttendees || 0) >= d.data().maxAttendees)
        }));

        const city = state.userProfile?.city;
        eventsData.localEvents = eventsData.all.filter(e => e.city === city);

        renderApp();
    });
    state.unsubscribers.push(unsubAll);
}

// --- UTILITIES ---
function formatPrice(event) {
    if (event.isFree) return `<span class="text-green-600 font-bold">Free</span>`;
    return `<span class="text-blue-600 font-bold">${event.ticketPrice || 'Paid'}</span>`;
}

// --- ACTIONS ---
export function setEditingEvent(id) {
    eventsData.editingEvent = eventsData.all.find(e => e.id === id);
    window.scrollTo(0, document.body.scrollHeight);
    renderApp();
}

export function clearEditingEvent() {
    eventsData.editingEvent = null;
    renderApp();
}

export async function handleCreateEvent(e) {
    e.preventDefault();
    if (!state.currentUser) return;

    const isFree = e.target.isFree.value === 'true';
    const maxAttendees = parseInt(e.target.maxAttendees.value) || 0;

    try {
        // UPDATED: Save 'isVerified' status to the event document
        await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'events'), {
            title: e.target.title.value,
            details: e.target.details.value,
            city: e.target.city.value,
            date: e.target.date.value,
            isFree: isFree,
            ticketPrice: isFree ? 'Free' : e.target.ticketPrice.value,
            paymentLink: e.target.paymentLink.value,
            maxAttendees: maxAttendees,
            currentAttendees: 0,
            postedByUid: state.currentUser.uid,
            postedByName: state.userProfile?.name || 'Verified Citizen',
            postedByVerified: state.userProfile?.isVerified || false, // Save Verification Status
            postedAt: new Date().toISOString()
        });
        state.adminMessage = "Event Created!";
        e.target.reset();
    } catch (error) {
        console.error("Error creating event:", error);
        state.adminMessage = "Error creating event.";
    }
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 3000);
}

export async function handleEditEvent(e, id) {
    e.preventDefault();
    const event = eventsData.all.find(e => e.id === id);
    if (!event || event.postedByUid !== state.currentUser.uid) return;

    const isFree = e.target.isFree.value === 'true';
    const maxAttendees = parseInt(e.target.maxAttendees.value) || 0;

    try {
        await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'events', id), {
            title: e.target.title.value,
            details: e.target.details.value,
            city: e.target.city.value,
            date: e.target.date.value,
            isFree: isFree,
            ticketPrice: isFree ? 'Free' : e.target.ticketPrice.value,
            paymentLink: e.target.paymentLink.value,
            maxAttendees: maxAttendees,
        });
        eventsData.editingEvent = null;
        state.adminMessage = "Event Updated!";
    } catch (error) {
        console.error("Error updating event:", error);
        state.adminMessage = "Error updating event.";
    }
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 3000);
}

export async function handleDeleteEvent(id) {
    if (!confirm("Are you sure you want to delete this event?")) return;
    const eventToDelete = eventsData.all.find(e => e.id === id);
    if (!eventToDelete || eventToDelete.postedByUid !== state.currentUser.uid) return;

    try {
        await deleteDoc(doc(db, 'artifacts', appId, 'public', 'data', 'events', id));
        state.adminMessage = "Event Deleted!";
    } catch (error) {
        console.error("Error deleting event:", error);
        state.adminMessage = "Error deleting event.";
    }
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 3000);
}

export async function handleRsvp(id) {
    const event = eventsData.all.find(e => e.id === id);
    if (!event || event.isSpaceFull) return;

    try {
        const newAttendees = (event.currentAttendees || 0) + 1;
        await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'events', id), {
            currentAttendees: newAttendees
        });
        state.adminMessage = `You've joined the guest list for ${event.title}!`;
    } catch (error) {
        console.error("Error RSVPing:", error);
        state.adminMessage = "Error joining event.";
    }
    renderApp();
    setTimeout(() => { state.adminMessage = ''; renderApp() }, 3000);
}

// --- RENDER UTILITY: Form ---
function renderEventForm(event = {}) {
    const isEditing = !!event.id;
    const title = isEditing ? 'Edit Your Event' : 'Post New Event';
    const action = isEditing ? `handleEditEvent(event, '${event.id}')` : `handleCreateEvent(event)`;
    const isFree = event.isFree === undefined ? true : event.isFree;

    return `
        <div class="bg-white p-6 rounded-xl shadow-lg mb-6 border ${isEditing ? 'border-yellow-400' : 'border-green-200'}">
            <h2 class="font-bold text-xl mb-4 border-b pb-2 ${isEditing ? 'text-yellow-700' : 'text-green-700'}">${title}</h2>
            <form onsubmit="${action}" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input name="title" placeholder="Event Title" value="${event.title || ''}" class="w-full p-2 border rounded text-sm md:col-span-2" required>
                <textarea name="details" placeholder="Event Details" class="w-full p-2 border rounded text-sm md:col-span-2" rows="4" required>${event.details || ''}</textarea>
                <select name="city" class="w-full p-2 border rounded text-sm">${cityOptions.replace(`value="${event.city}"`, `value="${event.city}" selected`)}</select>
                <input name="date" type="date" value="${event.date || ''}" class="w-full p-2 border rounded text-sm" required>
                <div class="flex items-center gap-4 p-2 border rounded bg-gray-50 md:col-span-2">
                    <label class="font-bold text-sm">Ticket Type:</label>
                    <input type="radio" name="isFree" value="true" id="free-ticket" ${isFree ? 'checked' : ''} onchange="document.getElementById('ticket-price-input').classList.add('hidden'); document.getElementById('payment-link-input').classList.add('hidden');"> <label for="free-ticket" class="mr-4">Free</label>
                    <input type="radio" name="isFree" value="false" id="paid-ticket" ${!isFree ? 'checked' : ''} onchange="document.getElementById('ticket-price-input').classList.remove('hidden'); document.getElementById('payment-link-input').classList.remove('hidden');"> <label for="paid-ticket">Paid</label>
                </div>
                <input id="ticket-price-input" name="ticketPrice" placeholder="Price (e.g., ₦5,000)" value="${event.ticketPrice || ''}" class="w-full p-2 border rounded text-sm ${isFree ? 'hidden' : ''}">
                <input name="maxAttendees" type="number" placeholder="Max Attendees (0 for unlimited)" value="${event.maxAttendees || 0}" class="w-full p-2 border rounded text-sm">
                <input id="payment-link-input" name="paymentLink" placeholder="Payment Link" value="${event.paymentLink || ''}" class="w-full p-2 border rounded text-sm md:col-span-2 ${isFree ? 'hidden' : ''}">
                <button type="submit" class="w-full bg-green-600 text-white py-2 rounded font-bold hover:bg-green-700 md:col-span-2">${isEditing ? 'Save Changes' : 'Post Event'}</button>
                ${isEditing ? `<button type="button" onclick="clearEditingEvent()" class="w-full bg-gray-300 text-gray-800 py-2 rounded hover:bg-gray-400 md:col-span-2">Cancel Edit</button>` : ''}
            </form>
        </div>`;
}

// --- RENDER ---
export function renderAllEvents() {
    const isUserLoggedIn = !!state.currentUser;
    const userCity = state.userProfile?.city || 'Lagos';

    const myEvents = eventsData.all.filter(e => e.postedByUid === state.currentUser?.uid);
    const allPublic = eventsData.all.filter(e => e.postedByUid !== state.currentUser?.uid);
    const localEvents = allPublic.filter(e => e.city === userCity);
    const otherEvents = allPublic.filter(e => e.city !== userCity);

    return `
    <div class="bg-gray-100 h-full p-4 overflow-y-auto pb-safe">
        <div class="max-w-4xl mx-auto space-y-6">
            <div class="flex justify-between items-center">
                <h1 class="text-2xl font-bold text-green-700">Events Hub</h1>
                <button onclick="setAppView('dashboard')" class="text-red-600 font-bold">Exit</button>
            </div>
            ${state.adminMessage ? `<div class="bg-green-100 text-green-700 p-2 rounded mb-4 fade-in">${state.adminMessage}</div>` : ''}

            ${isUserLoggedIn && myEvents.length > 0 ? `
            <div class="bg-white p-6 rounded-xl shadow-sm border border-green-200">
                <h2 class="font-bold text-xl mb-4 border-b pb-2 text-green-600">My Posted Events (${myEvents.length})</h2>
                <div class="space-y-4">${myEvents.map(e => renderEventCard(e, true)).join('')}</div>
            </div>` : ''}

            <div class="bg-white p-6 rounded-xl shadow-sm">
                <h2 class="font-bold text-xl mb-4 border-b pb-2 text-gray-800 flex items-center gap-2">
                    <i class="fas fa-map-marker-alt text-red-500"></i> Events in ${userCity} (${localEvents.length})
                </h2>
                <div class="space-y-4">
                    ${localEvents.map(e => renderEventCard(e, false)).join('')}
                    ${localEvents.length === 0 ? `<p class="text-gray-500 italic">No upcoming events found in ${userCity}.</p>` : ''}
                </div>
            </div>

            ${otherEvents.length > 0 ? `
            <div class="bg-white p-6 rounded-xl shadow-sm opacity-90">
                <h2 class="font-bold text-lg mb-4 border-b pb-2 text-gray-600">Events Elsewhere (${otherEvents.length})</h2>
                <div class="space-y-4">${otherEvents.map(e => renderEventCard(e, false)).join('')}</div>
            </div>` : ''}

            <div id="event-form-container" class="pt-4">
                ${isUserLoggedIn ? (eventsData.editingEvent ? renderEventForm(eventsData.editingEvent) : renderEventForm()) :
            `<div class="bg-blue-100 text-blue-700 p-4 rounded-xl text-center">Sign in to post and manage your own events.</div>`}
            </div>
        </div>
    </div>`;
}

// --- RENDER EVENT CARD WITH BADGE ---
function renderEventCard(e, isOwner) {
    const isFullBadge = e.isSpaceFull ? `<span class="bg-red-500 text-white text-xs px-2 py-1 rounded font-bold">SPACE FULL</span>` : '';
    const attendanceText = e.maxAttendees > 0 ? `${e.currentAttendees || 0} / ${e.maxAttendees} Attending` : 'Unlimited Space';
    const safeDetails = (e.details || '').substring(0, 150);

    // BADGE LOGIC: Check for e.postedByVerified
    const verifiedBadge = e.postedByVerified ? `<i class="fas fa-check-circle text-blue-500 ml-1" title="Verified Citizen"></i>` : '';

    let actionButton;
    if (isOwner) {
        actionButton = `
            <button onclick="setEditingEvent('${e.id}')" class="bg-yellow-500 text-white px-3 py-1 rounded text-sm hover:bg-yellow-600">Edit</button>
            <button onclick="handleDeleteEvent('${e.id}')" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600">Delete</button>
        `;
    } else if (e.isSpaceFull) {
        actionButton = `<button disabled class="bg-gray-300 text-gray-700 px-3 py-1 rounded text-sm">Full</button>`;
    } else if (e.isFree) {
        actionButton = `<button onclick="handleRsvp('${e.id}')" class="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700">RSVP</button>`;
    } else if (e.paymentLink) {
        actionButton = `<a href="${e.paymentLink}" target="_blank" class="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 inline-block">Buy Ticket</a>`;
    } else {
        actionButton = `<button disabled class="bg-gray-300 text-gray-700 px-3 py-1 rounded text-sm">Paid</button>`;
    }

    return `
    <div class="border p-4 rounded-xl shadow-sm bg-gray-50 hover:shadow-md transition-shadow">
        <div class="flex justify-between items-start mb-3">
            <div>
                <h3 class="font-bold text-lg text-gray-800">${e.title}</h3>
                <p class="text-sm text-gray-600 mt-1">${safeDetails}${safeDetails.length >= 150 ? '...' : ''}</p>
            </div>
            <div class="text-right flex flex-col items-end gap-1 flex-shrink-0">
                ${isFullBadge}
                ${formatPrice(e)}
            </div>
        </div>
        <div class="flex justify-between items-center text-xs text-gray-500 border-t pt-3">
            <div class="space-y-1">
                <p class="font-medium flex items-center gap-1"><i class="fas fa-calendar-alt text-green-500"></i> ${e.date} in <span class="text-gray-800 font-bold">${e.city}</span></p>
                <p class="font-medium flex items-center gap-1"><i class="fas fa-users text-blue-500"></i> ${attendanceText}</p>
                <p class="text-[10px] flex items-center">Posted by: <span class="font-bold ml-1">${e.postedByName || 'System'}</span> ${verifiedBadge}</p>
            </div>
            <div class="flex gap-2">
                ${actionButton}
            </div>
        </div>
    </div>`;
}