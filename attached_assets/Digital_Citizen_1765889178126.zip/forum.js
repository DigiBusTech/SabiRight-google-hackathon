import { db, appId, state, renderApp } from './shared.js';
import { collection, onSnapshot, addDoc, serverTimestamp, doc, getDoc, updateDoc, increment, deleteDoc, arrayUnion, arrayRemove } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

// --- STATE ---
export const forumData = {
    posts: [],
    replyingTo: {}
};

// --- LISTENERS ---
export function setupForumListener() {
    const city = state.userProfile?.city || 'Lagos';
    const unsub = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'forum_posts'), (snap) => {
        const rawPosts = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        forumData.posts = rawPosts.sort((a, b) => {
            if (a.city === city && b.city !== city) return -1;
            if (a.city !== city && b.city === city) return 1;
            const timeA = a.timestamp?.seconds || 0;
            const timeB = b.timestamp?.seconds || 0;
            return timeB - timeA;
        });
        renderApp();
    });
    state.unsubscribers.push(unsub);
}

// --- ACTIONS ---

export async function handleCreatePost(e) {
    e.preventDefault();
    const content = e.target.content.value;
    if (!content.trim()) return;

    // Safely get City/Author with Fallbacks
    const safeCity = state.userProfile.city || 'Lagos';
    const safeAuthor = state.userProfile.name || 'Citizen';

    try {
        await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'forum_posts'), {
            content,
            city: safeCity,
            author: safeAuthor,
            userId: state.currentUser.uid,
            isVerified: state.userProfile.isVerified || false,
            upvotes: 0,
            downvotes: 0,
            upvoters: [],
            downvoters: [],
            flagged: false,
            comments: [],
            timestamp: serverTimestamp()
        });
        e.target.reset();
    } catch (err) { console.error(err); alert("Post failed"); }
}

export async function handleVote(postId, type) {
    if (!state.currentUser) { alert("Please log in to vote."); return; }
    const userId = state.currentUser.uid;
    const postRef = doc(db, 'artifacts', appId, 'public', 'data', 'forum_posts', postId);
    const postSnap = await getDoc(postRef);
    if (!postSnap.exists()) return;
    const data = postSnap.data();
    const isUpvote = type === 'up';
    const voterArray = isUpvote ? 'upvoters' : 'downvoters';
    const counterField = isUpvote ? 'upvotes' : 'downvotes';
    const otherVoterArray = isUpvote ? 'downvoters' : 'upvoters';
    const otherCounterField = isUpvote ? 'downvotes' : 'upvotes';
    const updatePayload = {};
    if (data[voterArray]?.includes(userId)) {
        updatePayload[voterArray] = arrayRemove(userId);
        updatePayload[counterField] = increment(-1);
    } else if (data[otherVoterArray]?.includes(userId)) {
        updatePayload[otherVoterArray] = arrayRemove(userId);
        updatePayload[otherCounterField] = increment(-1);
        updatePayload[voterArray] = arrayUnion(userId);
        updatePayload[counterField] = increment(1);
    } else {
        updatePayload[voterArray] = arrayUnion(userId);
        updatePayload[counterField] = increment(1);
    }
    await updateDoc(postRef, updatePayload);
}

export async function handleFlag(postId) {
    if (!confirm("Flag this post?")) return;
    await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'forum_posts', postId), { flagged: true });
    alert("Post flagged.");
}

export async function handleDeletePost(postId) {
    if (!confirm("Delete this post?")) return;
    await deleteDoc(doc(db, 'artifacts', appId, 'public', 'data', 'forum_posts', postId));
}

export function initReply(postId, commentId, authorName) {
    forumData.replyingTo[postId] = { author: authorName, id: commentId };
    renderApp();
    setTimeout(() => {
        const input = document.getElementById(`input-${postId}`);
        if (input) input.focus();
    }, 100);
}

export function cancelReply(postId) {
    delete forumData.replyingTo[postId];
    renderApp();
}

export async function handleComment(e, postId) {
    e.preventDefault();
    const text = e.target.comment.value;
    if (!text) return;
    const postRef = doc(db, 'artifacts', appId, 'public', 'data', 'forum_posts', postId);
    const replyContext = forumData.replyingTo[postId];
    const newComment = {
        id: crypto.randomUUID(),
        text,
        author: state.userProfile.name || 'Citizen',
        userId: state.currentUser.uid,
        isVerified: state.userProfile.isVerified || false,
        likes: [],
        replyTo: replyContext ? replyContext.author : null,
        timestamp: new Date().toISOString()
    };
    await updateDoc(postRef, { comments: arrayUnion(newComment) });
    delete forumData.replyingTo[postId];
    e.target.reset();
    renderApp();
}

export async function handleCommentLike(postId, commentId) {
    if (!state.currentUser) return;
    const uid = state.currentUser.uid;
    const postRef = doc(db, 'artifacts', appId, 'public', 'data', 'forum_posts', postId);
    const snap = await getDoc(postRef);
    if (!snap.exists()) return;
    const comments = snap.data().comments || [];
    const commentIndex = comments.findIndex(c => c.id === commentId);
    if (commentIndex > -1) {
        const comment = comments[commentIndex];
        if (!comment.likes) comment.likes = [];
        if (comment.likes.includes(uid)) {
            comment.likes = comment.likes.filter(id => id !== uid);
        } else {
            comment.likes.push(uid);
        }
        comments[commentIndex] = comment;
        await updateDoc(postRef, { comments });
    }
}

// --- RENDER ---

export function renderForumList() {
    if (forumData.posts.length === 0) return '<p class="text-gray-500 text-center py-4">No discussions yet.</p>';

    return forumData.posts.map(post => {
        let timeDisplay = 'Just now';
        if (post.timestamp) {
            try { timeDisplay = post.timestamp.toDate().toLocaleDateString(); } catch (e) { }
        }

        const verifiedBadge = post.isVerified ? `<i class="fas fa-check-circle text-blue-500 ml-1" title="Verified"></i>` : '';
        const replyContext = forumData.replyingTo[post.id];

        // Fallback display for City if undefined
        const displayCity = (post.city && post.city !== 'undefined') ? post.city : 'Resident';

        return `
            <div class="border border-gray-200 rounded-lg p-4 mb-4 shadow-sm ${post.flagged ? 'opacity-50 bg-red-50' : 'bg-white'}">
                <div class="flex justify-between items-start mb-2">
                    <div>
                        <span class="font-bold text-gray-800">${post.author}</span> ${verifiedBadge}
                        <span class="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full ml-2 uppercase border">${displayCity}</span>
                    </div>
                    <div class="text-xs text-gray-400">${timeDisplay}</div>
                </div>
                
                <p class="text-gray-700 mb-3 text-sm">${post.flagged ? '<i class="text-red-500">[Flagged]</i>' : post.content}</p>
                
                <div class="flex items-center justify-between border-t pt-3">
                    <div class="flex space-x-4">
                        <button onclick="handleVote('${post.id}', 'up')" class="text-gray-500 hover:text-green-600 text-xs font-bold flex items-center gap-1">
                            <i class="fas fa-arrow-up"></i> ${post.upvotes || 0}
                        </button>
                        <button onclick="handleVote('${post.id}', 'down')" class="text-gray-500 hover:text-red-600 text-xs font-bold flex items-center gap-1">
                            <i class="fas fa-arrow-down"></i> ${post.downvotes || 0}
                        </button>
                        <button onclick="document.getElementById('comment-box-${post.id}').classList.toggle('hidden')" class="text-gray-500 hover:text-blue-600 text-xs flex items-center gap-1">
                            <i class="fas fa-comment-alt"></i> ${post.comments?.length || 0} Comments
                        </button>
                    </div>
                    <div class="flex gap-2">
                        ${(state.currentUser && (state.currentUser.uid === post.userId || state.isAdmin)) ?
                `<button onclick="handleDeletePost('${post.id}')" class="text-gray-400 hover:text-red-600 text-xs"><i class="fas fa-trash"></i></button>` : ''}
                        <button onclick="handleFlag('${post.id}')" class="text-gray-400 hover:text-red-500 text-xs"><i class="fas fa-flag"></i></button>
                    </div>
                </div>

                <div id="comment-box-${post.id}" class="hidden mt-3 pt-3 bg-gray-50 rounded p-3 border-t">
                    <div class="space-y-3 mb-3">
                    ${post.comments && post.comments.length > 0 ? post.comments.map(c => {
                    const isLiked = c.likes && state.currentUser && c.likes.includes(state.currentUser.uid);
                    const cVerified = c.isVerified ? `<i class="fas fa-check-circle text-blue-500 text-[10px]"></i>` : '';
                    const replyBadge = c.replyTo ? `<span class="text-gray-400 text-[10px] mx-1"><i class="fas fa-share"></i> ${c.replyTo}</span>` : '';

                    return `
                        <div class="text-xs border-b border-gray-200 pb-2 last:border-0">
                            <div class="flex justify-between items-start">
                                <div class="flex-grow">
                                    <span class="font-bold text-gray-700">${c.author}</span> ${cVerified}
                                    ${replyBadge}
                                    <p class="text-gray-600 mt-0.5">${c.text}</p>
                                </div>
                                <div class="flex items-center gap-3 flex-shrink-0 ml-2">
                                    <button onclick="handleCommentLike('${post.id}', '${c.id}')" class="${isLiked ? 'text-red-500' : 'text-gray-400 hover:text-red-500'} flex items-center gap-1">
                                        <i class="${isLiked ? 'fas' : 'far'} fa-heart"></i> ${c.likes ? c.likes.length : 0}
                                    </button>
                                    <button onclick="initReply('${post.id}', '${c.id}', '${c.author}')" class="text-blue-500 hover:underline">Reply</button>
                                </div>
                            </div>
                        </div>`;
                }).join('') : '<p class="text-xs text-gray-400 italic">No comments yet.</p>'}
                    </div>
                    
                    ${replyContext ? `
                        <div class="flex justify-between items-center bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mb-1">
                            <span>Replying to <b>@${replyContext.author}</b></span>
                            <button onclick="cancelReply('${post.id}')" class="hover:text-red-600"><i class="fas fa-times"></i></button>
                        </div>
                    ` : ''}

                    <form onsubmit="handleComment(event, '${post.id}')" class="flex gap-2">
                        <input id="input-${post.id}" name="comment" type="text" placeholder="${replyContext ? 'Write your reply...' : 'Write a comment...'}" class="flex-grow p-2 border rounded text-xs" autocomplete="off" required>
                        <button type="submit" class="bg-blue-600 text-white px-3 rounded text-xs font-bold">Send</button>
                    </form>
                </div>
            </div>`;
    }).join('');
}