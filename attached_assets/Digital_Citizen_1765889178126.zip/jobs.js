import { db, appId, state, renderApp, cityOptions, sectorOptions, runGemini } from './shared.js';
import { collection, query, where, getDocs, addDoc, serverTimestamp, limit, orderBy, onSnapshot } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

// --- STATE ---
export const jobsData = {
    matches: [], 
    viewMode: 'search', // 'search' or 'create'
    isSearching: false,
    lastSearchFilters: null,
    message: ''
};

// --- LISTENERS ---
export function setupJobsListener() {
    const q = query(collection(db, 'artifacts', appId, 'public', 'data', 'jobs'), orderBy('postedAt', 'desc'), limit(50));
    
    const unsub = onSnapshot(q, (snap) => {
        // Only update the main list if the user isn't actively searching
        if (!jobsData.isSearching) {
            jobsData.matches = snap.docs.map(d => ({ id: d.id, ...d.data() }));
            // Apply initial filtering based on user city for the list view
            handleInitialCityFilter(); 
            renderApp();
        }
    });
    state.unsubscribers.push(unsub);
}

// Function to filter jobs by user's city (used on initial load)
function handleInitialCityFilter() {
    const city = state.userProfile?.city || 'Lagos';
    const initialMatches = jobsData.matches.filter(j => j.location === city || j.location === 'Remote');
    
    // Set a filtered list for the initial view
    if (initialMatches.length > 0) {
        jobsData.matches = initialMatches;
        jobsData.message = `Showing jobs relevant to your city: ${city}`;
    } else {
        jobsData.message = `No direct matches in ${city}. Use the search to find more!`;
    }
}

// --- ACTIONS ---
export function setJobView(mode) {
    jobsData.viewMode = mode;
    jobsData.message = '';
    renderApp();
}

/**
 * UPDATED LOGIC: Apply button now displays contact/email. Application link moves to Source.
 */
export function revealContact(id, contact) {
    const btn = document.getElementById(`apply-btn-${id}`);
    
    // Always update the button text to show the contact information
    const text = contact.includes('@') ? `Email: ${contact}` : `Contact: ${contact}`;

    btn.innerText = text;
    btn.classList.remove('bg-blue-600', 'text-white', 'hover:bg-blue-700');
    btn.classList.add('bg-green-100', 'text-green-800', 'cursor-default');
}

export async function handleUserCreateJob(e) {
    e.preventDefault();
    if (!state.userProfile) {
        jobsData.message = "Error: You must be logged in.";
        renderApp();
        return;
    }
    jobsData.isSearching = true; 
    renderApp();
    try {
        await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'jobs'), {
            title: e.target.title.value,
            location: e.target.location.value,
            sector: e.target.sector.value,
            type: e.target.type.value,
            workMode: e.target.workMode.value,
            salary: e.target.salary.value || 'Negotiable',
            contact: e.target.contact.value,
            description: e.target.description.value,
            source: 'User Posted',
            postedBy: state.currentUser.uid,
            postedAt: serverTimestamp()
        });
        jobsData.message = "Job Posted Successfully!";
        jobsData.viewMode = 'search';
    } catch (err) {
        console.error(err);
        jobsData.message = "Failed to post job.";
    }
    jobsData.isSearching = false;
    renderApp();
}

// --- HELPER: FALLBACK GENERATOR ---
function generateFallbackJobs(filters) {
    const roles = [filters.role || "Administrative Officer", "Business Developer", "Project Assistant"];
    const companies = ["BlueChip Nigeria", "Lagos Tech Solutions", "Green Energy Ltd", "First Zenith Bank"];
    return roles.map((role, i) => ({
        title: role,
        company: companies[i] || "Generic Corp",
        location: filters.location !== 'All' ? filters.location : 'Lagos',
        sector: filters.sector !== 'All' ? filters.sector : 'General',
        type: filters.type !== 'All' ? filters.type : 'Full-time',
        workMode: filters.workMode !== 'All' ? filters.workMode : 'Onsite',
        salary: "₦150,000 - ₦300,000",
        contact: "hr@example-company.com.ng",
        // Fallback description now uses Markdown
        description: `**Job Description**
        
**(Simulation)** We are looking for a capable **${role}** to join our team in Lagos. This result is generated because the AI API limit was reached or blocked.
        
**Key Responsibilities:**
* Manage daily reports and department schedules.
* Coordinate internal and external communication.
* Assist the Project Manager with logistics and documentation.
        
**Requirements:**
* Minimum 2 years of relevant experience.
* Proficiency in MS Office Suite.
        
**About**
We are a leading firm committed to digital innovation in Nigeria.`,
        source: "Simulation (API Fallback)"
    }));
}

// --- HELPER: SOURCE DISPLAY LOGIC (Now includes the application link) ---
function getJobSourceDisplay(job) {
    let sourceName = job.source || 'Internal/Unknown';
    let displayLink = null;
    
    if (job.source === 'User Posted' || job.source === 'Internal') {
        return `<span class="text-[10px] text-gray-500 font-medium">Source: Posted by a Digital Citizen</span>`;
    }

    // PRIORITY 1: Use the CONTACT field if it is a URL (The Application Link)
    if (job.contact && job.contact.startsWith('http')) {
        displayLink = job.contact;
        sourceName = sourceName.includes('Fetched') ? "Application Link" : sourceName;
    } 
    // PRIORITY 2: Fallback to common job platform links if it's AI-fetched but contact wasn't URL
    else if (job.source && job.isAiFetched) {
        if (sourceName.toLowerCase().includes('linkedin')) {
            displayLink = 'https://www.linkedin.com/jobs/';
        } else if (sourceName.toLowerCase().includes('jobberman')) {
            displayLink = 'https://www.jobberman.com/';
        } else if (sourceName.toLowerCase().includes('indeed')) {
            displayLink = 'https://ng.indeed.com/';
        }
    }
    
    if (displayLink) {
        return `<a href="${displayLink}" target="_blank" class="text-[10px] text-blue-500 hover:text-blue-700 font-bold underline">Source: ${sourceName} <i class="fas fa-external-link-alt ml-1"></i></a>`;
    } else {
        return `<span class="text-[10px] text-gray-400">Source: ${sourceName}</span>`;
    }
}


// --- AI + DB SEARCH ENGINE ---
export async function handleJobSearch(e) {
    e.preventDefault();
    jobsData.isSearching = true;
    jobsData.message = "Searching database...";
    renderApp();

    const filters = {
        location: e.target.location.value,
        sector: e.target.sector.value,
        role: e.target.role.value,
        type: e.target.type.value,
        workMode: e.target.workMode.value
    };
    jobsData.lastSearchFilters = filters;

    try {
        // 1. SEARCH DATABASE (using the full 50-job set from listener)
        const dbRef = collection(db, 'artifacts', appId, 'public', 'data', 'jobs');
        const dbSnap = await getDocs(query(dbRef, orderBy('postedAt', 'desc'), limit(100)));
        let results = dbSnap.docs.map(d => ({id: d.id, ...d.data()}));

        // Filter locally
        results = results.filter(job => {
            const matchLoc = filters.location === 'All' || job.location === filters.location;
            const matchSec = filters.sector === 'All' || job.sector === filters.sector;
            const matchType = filters.type === 'All' || job.type === filters.type;
            const matchMode = filters.workMode === 'All' || job.workMode === filters.workMode;
            const matchRole = !filters.role || job.title.toLowerCase().includes(filters.role.toLowerCase()) || (job.description && job.description.toLowerCase().includes(filters.role.toLowerCase()));
            return matchLoc && matchSec && matchType && matchMode && matchRole;
        });

        // 2. IF RESULTS LOW, USE AI AGENT
        if (results.length < 3 || filters.role) {
            jobsData.message = "Contacting AI Specialist for a personalized match...";
            renderApp();

            // *** UPDATED AI PROMPT FOR BOLDING HEADINGS AND FORMATTING ***
            const aiPrompt = `
                Act as a Job Search API for Nigeria.
                Criteria: Role: ${filters.role || 'General'}, Location: ${filters.location}, Sector: ${filters.sector}.
                
                Task: List 3 highly realistic job opportunities matching these criteria.
                
                CRITICAL INSTRUCTIONS:
                1. The 'description' must be a full, comprehensive job description (at least 100 words). **Format the description using Markdown (bullet points, paragraphs, bolding). Specifically, ensure headings like 'About', 'Requirements:', 'Key Responsibilities:', and 'Job Description' are BOLD.**
                2. The 'contact' field must be the direct application URL if possible, otherwise a company email address.
                3. The 'source' field must be the name of the external job platform (e.g., LinkedIn, Jobberman).
                
                Output: Return ONLY a JSON Array of objects. No markdown, no text.
                Schema: [{"title": "...", "company": "...", "location": "...", "sector": "...", "type": "...", "workMode": "...", "salary": "...", "contact": "Application URL or Email", "description": "Formatted Job Description in Markdown", "source": "Platform Name"}]
            `;

            const aiResponse = await runGemini(aiPrompt);
            
            if (aiResponse) {
                try {
                    const jsonMatch = aiResponse.match(/\[.*\]/s);
                    const cleanJson = jsonMatch ? jsonMatch[0] : aiResponse;
                    
                    const newJobs = JSON.parse(cleanJson);
                    for (const job of newJobs) {
                        results.push({ ...job, isAiFetched: true });
                        addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'jobs'), {
                            ...job,
                            postedAt: serverTimestamp(),
                            isAiFetched: true
                        });
                    }
                } catch (e) {
                    console.warn("AI JSON Parse Error", e);
                }
            } else {
                console.warn("AI Blocked/Failed. Using Fallback.");
                const fallbackData = generateFallbackJobs(filters);
                fallbackData.forEach(job => results.push(job));
                jobsData.message = "Showing simulated matches (AI Busy/Error).";
            }
        }

        jobsData.matches = results;
        if(!jobsData.message.includes("Busy")) {
            jobsData.message = `Found ${results.length} matches.`;
        }

    } catch (err) {
        console.error(err);
        jobsData.message = "Error performing search.";
    }

    jobsData.isSearching = false;
    renderApp();
}

// --- RENDER ---
export function renderAllJobs() {
    const city = state.userProfile?.city || 'Lagos';
    if (jobsData.viewMode === 'create') return renderCreateJobForm();

    return `
    <div class="bg-gray-100 h-full flex flex-col overflow-hidden pb-safe">
        <div class="bg-white p-4 shadow-sm flex flex-col gap-4 z-10">
            <div class="flex justify-between items-center">
                <div class="flex items-center gap-2">
                    <button onclick="setAppView('dashboard')" class="text-gray-600"><i class="fas fa-arrow-left"></i></button>
                    <h1 class="font-bold text-xl">Find Jobs</h1>
                </div>
                <button onclick="window.setJobView('create')" class="bg-blue-600 text-white text-xs px-3 py-2 rounded font-bold shadow hover:bg-blue-700">
                    <i class="fas fa-plus"></i> Post Job
                </button>
            </div>
            
            ${jobsData.matches.length === 0 && !jobsData.isSearching ? `
                <div class="text-center p-4 bg-yellow-50 rounded-lg border border-yellow-100">
                    <p class="text-sm font-semibold text-yellow-800 mb-2">Want our AI specialist to match you with a job?</p>
                    <button onclick="document.querySelector('form').scrollIntoView();" class="bg-yellow-600 text-white py-2 px-4 rounded font-bold hover:bg-yellow-700 shadow-md">
                        <i class="fas fa-robot mr-2"></i> Start AI Match
                    </button>
                </div>
            ` : ''}

            <form onsubmit="handleJobSearch(event)" class="bg-blue-50 p-3 rounded-lg border border-blue-100 text-sm space-y-2">
                <p class="text-xs font-bold text-blue-800">Filter or use 'Role' for AI Match:</p>
                <div class="grid grid-cols-2 gap-2">
                    <select name="location" class="border p-2 rounded w-full">
                        <option value="All">All Locations</option>
                        <option value="${city}" selected>Current: ${city}</option>
                        ${cityOptions}
                    </select>
                    <select name="sector" class="border p-2 rounded w-full">
                        <option value="All">All Sectors</option>
                        ${sectorOptions}
                    </select>
                </div>
                <div class="grid grid-cols-3 gap-2">
                    <select name="type" class="border p-2 rounded w-full">
                        <option value="All">Any Type</option>
                        <option value="Full-time">Full-time</option>
                        <option value="Part-time">Part-time</option>
                    </select>
                    <select name="workMode" class="border p-2 rounded w-full">
                        <option value="All">Any Mode</option>
                        <option value="Onsite">Onsite</option>
                        <option value="Remote">Remote</option>
                        <option value="Hybrid">Hybrid</option>
                    </select>
                    <input name="role" placeholder="Role (e.g. Driver)" class="border p-2 rounded w-full">
                </div>
                <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded font-bold hover:bg-blue-700 flex justify-center items-center gap-2">
                    ${jobsData.isSearching ? '<i class="fas fa-spinner fa-spin"></i> Running Search & AI Match...' : '<i class="fas fa-search"></i> Search / Match Jobs'}
                </button>
            </form>
            ${jobsData.message ? `<p class="text-xs text-center ${jobsData.message.includes('Error') ? 'text-red-600' : 'text-green-600'}">${jobsData.message}</p>` : ''}
        </div>

        <div class="flex-grow overflow-y-auto p-4 space-y-4">
            ${jobsData.matches.length === 0 && !jobsData.isSearching ? `
                <div class="text-center text-gray-500 mt-10">
                    <i class="fas fa-search text-4xl mb-3 text-gray-300"></i>
                    <p>Start by searching or using the AI match button above.</p>
                </div>` : ''}
            
            ${jobsData.matches.map(job => `
                <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-200 relative overflow-hidden">
                    ${job.source === 'Simulation (API Fallback)' ? '<div class="absolute top-0 right-0 bg-gray-200 text-gray-600 text-[10px] px-2 py-1 font-bold">Simulation</div>' : 
                      (job.source !== 'User Posted' && job.source !== 'Internal' ? '<div class="absolute top-0 right-0 bg-purple-100 text-purple-800 text-[10px] px-2 py-1 font-bold">AI Fetched</div>' : '')}
                    
                    <div class="flex justify-between items-start mb-2">
                        <div>
                            <h2 class="font-bold text-lg text-blue-900 leading-tight">${job.title}</h2>
                            <p class="text-sm font-semibold text-gray-700">${job.company || 'Digital Citizen Network'}</p>
                        </div>
                    </div>

                    <div class="flex flex-wrap gap-2 mb-3">
                        <span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded border"><i class="fas fa-map-marker-alt mr-1"></i>${job.location}</span>
                        <span class="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded border border-blue-100">${job.type}</span>
                        <span class="text-xs bg-green-50 text-green-700 px-2 py-1 rounded border border-green-100">${job.workMode || 'Onsite'}</span>
                        ${job.salary ? `<span class="text-xs bg-yellow-50 text-yellow-700 px-2 py-1 rounded border border-yellow-100">${job.salary}</span>` : ''}
                    </div>

                    <div class="text-sm text-gray-600 mb-3 markdown-content">${marked.parse(job.description || 'No detailed description provided.')}</div>
                    
                    <div class="border-t pt-3 flex justify-between items-center">
                        ${getJobSourceDisplay(job)}
                        
                        <button id="apply-btn-${job.id}" onclick="revealContact('${job.id}', '${job.contact}')" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-blue-700 transition shadow-sm">
                            Apply Now
                        </button>
                    </div>
                </div>
            `).join('')}
        </div>
    </div>`;
}

function renderCreateJobForm() {
    return `
    <div class="bg-gray-100 h-full flex flex-col overflow-y-auto pb-safe">
        <div class="bg-white p-4 shadow-sm flex items-center gap-4">
            <button onclick="window.setJobView('search')" class="text-gray-600"><i class="fas fa-arrow-left"></i> Cancel</button>
            <h1 class="font-bold text-xl">Post a Job</h1>
        </div>
        <div class="p-4 max-w-lg mx-auto w-full">
            <div class="bg-white p-6 rounded-xl shadow border">
                <h2 class="font-bold text-gray-800 mb-4">Job Details</h2>
                <form onsubmit="handleUserCreateJob(event)" class="space-y-4">
                    <div>
                        <label class="text-xs font-bold text-gray-500 uppercase">Job Title</label>
                        <input name="title" class="w-full p-2 border rounded focus:ring-2 ring-blue-500 outline-none" required>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="text-xs font-bold text-gray-500 uppercase">Location</label>
                            <select name="location" class="w-full p-2 border rounded text-sm bg-white">${cityOptions}</select>
                        </div>
                        <div>
                            <label class="text-xs font-bold text-gray-500 uppercase">Sector</label>
                            <select name="sector" class="w-full p-2 border rounded text-sm bg-white">${sectorOptions}</select>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="text-xs font-bold text-gray-500 uppercase">Type</label>
                            <select name="type" class="w-full p-2 border rounded text-sm bg-white">
                                <option>Full-time</option>
                                <option>Part-time</option>
                                <option>Contract</option>
                            </select>
                        </div>
                        <div>
                            <label class="text-xs font-bold text-gray-500 uppercase">Mode</label>
                            <select name="workMode" class="w-full p-2 border rounded text-sm bg-white">
                                <option>Onsite</option>
                                <option>Remote</option>
                                <option>Hybrid</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label class="text-xs font-bold text-gray-500 uppercase">Salary Range</label>
                        <input name="salary" placeholder="e.g. ₦150,000 - ₦200,000" class="w-full p-2 border rounded">
                    </div>
                    <div>
                        <label class="text-xs font-bold text-gray-500 uppercase">Application Link / Email</label>
                        <input name="contact" placeholder="https://... or email@company.com" class="w-full p-2 border rounded" required>
                    </div>
                    <div>
                        <label class="text-xs font-bold text-gray-500 uppercase">Description</label>
                        <textarea name="description" rows="4" class="w-full p-2 border rounded" required></textarea>
                    </div>
                    <button type="submit" class="w-full bg-green-600 text-white py-3 rounded font-bold hover:bg-green-700 shadow-lg">
                        ${jobsData.isSearching ? '<i class="fas fa-spinner fa-spin"></i> Posting...' : 'Post Job'}
                    </button>
                </form>
            </div>
        </div>
    </div>`;
}

window.setJobView = setJobView;
window.handleJobSearch = handleJobSearch;
window.handleUserCreateJob = handleUserCreateJob;