// --- IMPORTS ---
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

// --- MARKDOWN SETUP ---
if (typeof marked !== 'undefined') {
    marked.setOptions({ breaks: true, gfm: true });
}

// --- CONFIGURATION & EXPORTS ---

// **ACTION REQUIRED:** If Job Search fails with a 404, replace this key 
// with a brand new key from a project that has the Gemini API enabled.
export const GEMINI_API_KEY = "AIzaSyDHS9rhr32rbszdm3Dtb9zecEGmgpi9HE4";

export const appId = typeof __app_id !== 'undefined' ? __app_id : 'digital-citizen-v2';

const firebaseConfig = {
    apiKey: "AIzaSyBrtOCOwXp8UloT0nDqzQDpZpHgtrJUQBs",
    authDomain: "legal-13d13.firebaseapp.com",
    projectId: "legal-13d13",
    storageBucket: "legal-13d13.firebasestorage.app",
    messagingSenderId: "482238213242",
    appId: "1:482238213242:web:435d5002b58d97b3349fc3"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// --- CONSTANTS ---
export const BAD_WORDS = ["fuck", "shit", "bitch", "stupid", "fool", "idiot"];

export const NIGERIAN_CITIES = [
    "Abuja (FCT)", "Abakaliki (Ebonyi)", "Abeokuta (Ogun)", "Ado Ekiti (Ekiti)", "Akure (Ondo)", "Asaba (Delta)",
    "Awka (Anambra)", "Bauchi (Bauchi)", "Benin City (Edo)", "Birnin Kebbi (Kebbi)", "Calabar (Cross River)",
    "Damaturu (Yobe)", "Dutse (Jigawa)", "Enugu (Enugu)", "Gombe (Gombe)", "Gusau (Zamfara)", "Ibadan (Oyo)",
    "Ikeja (Lagos)", "Ilorin (Kwara)", "Jalingo (Taraba)", "Jos (Plateau)", "Kaduna (Kaduna)", "Kano (Kano)",
    "Katsina (Katsina)", "Lafia (Nasarawa)", "Lagos", "Lokoja (Kogi)", "Maiduguri (Borno)", "Makurdi (Benue)",
    "Minna (Niger)", "Osogbo (Osun)", "Owerri (Imo)", "Port Harcourt (Rivers)", "Sokoto (Sokoto)",
    "Umuahia (Abia)", "Uyo (Akwa Ibom)", "Yenagoa (Bayelsa)", "Yola (Adamawa)"
].sort();

export const JOB_SECTORS = [
    "Technology & Software", "Legal & Compliance", "Healthcare", "Education", "Finance & Banking",
    "Oil & Gas", "Construction", "Sales & Marketing", "Administrative", "Customer Service", "Creative & Media"
].sort();

// Create HTML Options strings
export const cityOptions = NIGERIAN_CITIES.map(c => `<option value="${c}">${c}</option>`).join('');
export const sectorOptions = JOB_SECTORS.map(s => `<option value="${s}">${s}</option>`).join('');

export const MOCK_DIRECTORY = {
    "Lagos": [
        { name: "NBA Lagos Branch", type: "Legal Aid", contact: "0800-LAWYER-NG" },
        { name: "Lagos Emergency", type: "Emergency", contact: "112 / 767" },
        { name: "LASUTH Ikeja", type: "Health", contact: "01-555-1234" }
    ],
    "Abuja (FCT)": [
        { name: "Legal Aid Council HQ", type: "Legal Aid", contact: "09-234-5678" },
        { name: "National Hospital", type: "Health", contact: "09-234-1111" }
    ],
    "Port Harcourt (Rivers)": [
        { name: "Rivers State Police Command", type: "Security", contact: "0803-123-4567" }
    ]
};

// --- GLOBAL STATE ---
export const state = {
    appContainer: document.getElementById('app'),
    currentUser: null,
    userProfile: null,
    isAdmin: false,
    authMode: 'login',
    authError: '',
    isAuthLoading: false,
    adminMessage: '',
    currentView: 'dashboard',
    unsubscribers: []
};

// --- UTILITIES ---
export function censorText(text) {
    let cleanText = text;
    BAD_WORDS.forEach(word => {
        const regex = new RegExp(word, "gi");
        cleanText = cleanText.replace(regex, "*".repeat(word.length));
    });
    return cleanText;
}

// --- GEMINI AI HELPER (Most Stable Configuration) ---
export async function runGemini(prompt) {
    // 1. Try gemini-2.5-flash (Most current stable model, v1 API)
    let result = await tryModel('gemini-2.5-flash', 'v1', GEMINI_API_KEY, prompt);

    // 2. If failed, try gemini-pro (Older, but often reliable, v1 API)
    if (!result) {
        console.warn("Switching to fallback model (gemini-pro)...");
        result = await tryModel('gemini-pro', 'v1', GEMINI_API_KEY, prompt);
    }

    return result;
}

async function tryModel(model, version, key, prompt) {
    try {
        const url = `https://generativelanguage.googleapis.com/${version}/models/${model}:generateContent?key=${key}`;
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
        });

        if (!response.ok) {
            console.warn(`Gemini API Error (Status ${response.status}) on ${model}.`);
            return null;
        }
        const data = await response.json();
        return data?.candidates?.[0]?.content?.parts?.[0]?.text || null;
    } catch (e) {
        return null;
    }
}

// --- RENDER FUNCTION EXPORTS ---
export let renderApp = () => console.log("Render function not yet initialized");
export const setRenderApp = (fn) => { renderApp = fn; };