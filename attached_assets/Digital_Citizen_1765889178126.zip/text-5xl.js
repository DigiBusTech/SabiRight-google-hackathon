// --- IMPORTS ---
import { app, auth, db, state, setRenderApp, appId, cityOptions } from './shared.js';
import { onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, updateProfile } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { doc, getDoc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

// --- MODULE IMPORTS ---
import { renderAdmin, handleAdminStatusUpdate, handleAdminAddJob, handleAdminAddEvent, handleReinstatePost, setEditingEventAdmin, clearEditingEventAdmin, handleAdminEditEvent, handleAdminDeleteEvent, handleAdminEditJob, handleAdminDeleteJob, loadAdminJobs, setEditingJob, clearEditingJob, loadAdminUsers, setEditingUser, clearEditingUser, handleAdminUpdateUser, handleToggleVerifyUser } from './admin.js';
import { renderCivicCenter, setupCivicListener, seedCityData, fetchTrafficUpdate, civicData } from './civic.js';
import { renderAllJobs, setupJobsListener, revealContact, jobsData } from './jobs.js';
import { renderAllEvents, setupEventsListener, eventsData, handleCreateEvent, handleEditEvent, handleDeleteEvent, handleRsvp, setEditingEvent, clearEditingEvent } from './events.js';
import { renderForumList, setupForumListener, handleCreatePost, handleVote, handleFlag, handleComment, handleDeletePost, handleCommentLike, initReply, cancelReply } from './forum.js';
import { renderAgent, handleAgentSubmit, toggleUrgency } from './ai_agent.js';
import { renderDirectory } from './directory.js'

// --- INITIALIZATION ---

async function initApp() {
    try {
        setRenderApp(render);

        onAuthStateChanged(auth, async (user) => {
            if (user) {
                state.currentUser = user;
                state.isAdmin = user.email.startsWith('admin');
                await fetchUserProfile(user.uid);

                state.unsubscribers.forEach(u => u());
                state.unsubscribers = [];
                setupCivicListener();
                setupJobsListener();
                setupEventsListener();
                setupForumListener();

            } else {
                state.currentUser = null;
                state.userProfile = null;
                state.isAdmin = false;
                state.unsubscribers.forEach(unsub => unsub());
            }
            render();
        });
    } catch (error) {
        if (state.appContainer) state.appContainer.innerHTML = `<div class="p-10 text-center text-red-600 font-bold">${error.message}</div>`;
        console.error(error);
    }
}

async function fetchUserProfile(uid) {
    try {
        const docRef = doc(db, 'artifacts', appId, 'users', uid, 'profile', 'main');
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
            const data = docSnap.data();
            // ROBUST FALLBACK: Ensure we never have undefined Name or City in state
            state.userProfile = {
                ...data,
                name: data.name || state.currentUser.displayName || 'Citizen',
                city: data.city || 'Lagos', // Default to Lagos if city missing
                isVerified: !!data.isVerified
            };
        } else {
            // Fallback if profile document is completely missing
            state.userProfile = { 
                name: state.currentUser.displayName || 'Citizen', 
                city: 'Lagos', 
                isVerified: false 
            };
        }
    } catch (e) {
        console.error("Profile fetch error:", e);
        state.userProfile = { name: 'Citizen', city: 'Lagos', isVerified: false };
    }
}

// --- AUTH HANDLERS ---
async function handleLogin(e) {
    e.preventDefault();
    state.isAuthLoading = true;
    render();
    try {
        await signInWithEmailAndPassword(auth, e.target.email.value, e.target.password.value);
    } catch (error) {
        state.authError = "Invalid Email or Password";
        state.isAuthLoading = false;
        render();
    }
}

async function handleSignUp(e) {
    e.preventDefault();
    state.isAuthLoading = true;
    render();
    try {
        const uc = await createUserWithEmailAndPassword(auth, e.target.email.value, e.target.password.value);
        await updateProfile(uc.user, { displayName: e.target.fullname.value });

        const profileData = {
            name: e.target.fullname.value,
            email: e.target.email.value,
            city: e.target.city.value,
            joinedAt: serverTimestamp(),
            role: e.target.email.value.startsWith('admin') ? 'admin' : 'user',
            isVerified: false
        };

        // 1. Create Private Profile
        await setDoc(doc(db, 'artifacts', appId, 'users', uc.user.uid, 'profile', 'main'), profileData);

        // 2. Create Directory Entry
        await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'users_directory', uc.user.uid), {
            ...profileData,
            uid: uc.user.uid
        });
        
        // 3. CRITICAL: Set state immediately so UI works before DB fetch
        state.userProfile = profileData; 

        await seedCityData(e.target.city.value);
    } catch (error) {
        state.authError = error.message;
        state.isAuthLoading = false;
        render();
    }
}

// --- DASHBOARD RENDERER ---
function renderDashboard() {
    const city = state.userProfile?.city || 'Unknown';
    const statusText = civicData.status?.status || 'Loading...';
    let statusClass = statusText === 'Safe' ? 'status-safe bg-green-50 text-green-800' : statusText === 'Alert' ? 'status-alert bg-yellow-50 text-yellow-800' : 'status-danger bg-red-50 text-red-800';
    const smartSummary = `${new Date().getHours() < 12 ? 'Good Morning' : 'Good Evening'}, ${state.userProfile?.name}. Do not forget to check for Events hapening in ${state.userProfile?.city} this week.`;
    
    // FIX: Make job location filtering case-insensitive for reliable matching
    const userCityJobs = jobsData.matches.filter(job => 
        (job.location && city && job.location.toLowerCase() === city.toLowerCase()) || 
        (job.location && job.location.toLowerCase() === 'remote')
    );

    let trafficHtml = '';
    if (civicData.isTrafficLoading) {
        trafficHtml = `<div class="mt-3 p-3 bg-white bg-opacity-60 rounded border animate-pulse flex items-center gap-3"><i class="fas fa-satellite-dish fa-spin text-blue-600"></i><span class="text-sm text-gray-600">Scanning live traffic satellites...</span></div>`;
    } else if (civicData.trafficData) {
        const renderT = (streets, label, color, icon) => streets?.length ? `<h4 class="font-bold mt-3 text-sm flex items-center gap-2 ${color}">${icon} ${label} Traffic (${streets.length})</h4><ul class="text-xs text-gray-700 ml-4 list-disc list-inside">${streets.map(s => `<li>${s}</li>`).join('')}</ul>` : '';
        const heavyHtml = renderT(civicData.trafficData.heavy, 'Heavy', 'text-red-700', '<i class="fas fa-car-crash"></i>');
        const moderateHtml = renderT(civicData.trafficData.moderate, 'Moderate', 'text-yellow-700', '<i class="fas fa-traffic-light"></i>');
        const lightHtml = renderT(civicData.trafficData.light, 'Light', 'text-green-700', '<i class="fas fa-road"></i>');
        trafficHtml = `<div class="mt-3 p-3 bg-white bg-opacity-90 rounded border shadow-sm fade-in"><div class="flex justify-between items-start mb-2 border-b pb-2"><h4 class="font-bold text-sm uppercase text-gray-700">Live Traffic AI Report</h4><span class="text-[10px] bg-blue-100 text-blue-800 px-1 rounded">AI-Grounded</span></div><p class="text-sm text-gray-800 mb-3">${civicData.trafficData.summary}</p><div class="space-y-2">${heavyHtml}${moderateHtml}${lightHtml}</div></div>`;
    }

    return `
    <div class="bg-gray-100 h-full flex flex-col overflow-hidden relative">
        <header class="bg-white shadow-sm flex-shrink-0 px-4 py-3 flex justify-between items-center z-10">
            <div class="flex items-center space-x-3"><div class="bg-red-600 text-white p-2 rounded"><i class="fas fa-passport"></i></div><div><h1 class="font-bold text-gray-800">Digital Citizen</h1><p class="text-xs text-gray-500">${city}</p></div></div>
            <div class="flex items-center space-x-2">
                ${state.isAdmin ? `<button onclick="setAppView('admin')" class="bg-red-100 text-red-700 px-3 py-1 rounded text-sm font-bold">Admin</button>` : ''}
                <button onclick="setAppView('directory')" class="hidden sm:block bg-blue-100 text-blue-700 px-3 py-1 rounded text-sm font-bold">Directory</button>
                <button onclick="handleSignOut()" class="text-gray-500 hover:text-red-600"><i class="fas fa-sign-out-alt text-xl"></i></button>
            </div>
        </header>

        <main id="main-scroll-container" class="flex-grow overflow-y-auto p-4 pb-24 w-full">
            <div class="max-w-7xl mx-auto space-y-6">
                <div class="p-6 bg-gradient-to-r from-blue-600 to-indigo-700 rounded-xl shadow-lg text-white"><h2 class="text-lg font-medium italic opacity-95">${smartSummary}</h2></div>

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div class="lg:col-span-2 space-y-6">
                        <div class="bg-white rounded-xl shadow-sm p-6 ${statusClass}">
                            <div class="flex justify-between items-center mb-2"><div class="flex items-center gap-2"><h3 class="font-bold text-lg">Civic Status</h3><button onclick="setAppView('civic')" class="text-xs bg-white bg-opacity-50 px-2 py-1 rounded border border-current">View Full</button></div><button onclick="fetchTrafficUpdate()" class="bg-white bg-opacity-60 hover:bg-opacity-100 border border-current text-xs font-bold px-3 py-1 rounded transition-all flex items-center gap-1"><i class="fas fa-sync-alt ${civicData.isTrafficLoading ? 'fa-spin' : ''}"></i> Check Traffic</button></div>
                            <p class="mb-2 font-bold">${statusText}</p><p class="mb-2 text-sm">${civicData.status?.traffic_alert || 'Loading status...'}</p>${trafficHtml}
                        </div>

                        <div class="bg-white rounded-xl shadow-sm p-6">
                            <div class="flex justify-between items-center mb-4"><h3 class="font-bold text-lg text-blue-600">AI + Human Curated Opportunities</h3><div class="flex space-x-2"><button onclick="setAppView('jobs')" class="text-sm bg-green-50 text-green-700 px-3 py-1 rounded font-bold hover:bg-green-100">Match</button><button onclick="setAppView('jobs')" class="text-sm text-blue-600 hover:underline">View All</button></div></div>
                            <p class="text-xs text-gray-500 mb-4">Showing ${userCityJobs.length} matches in ${city} (including Remote) based on your profile.</p>
                            ${userCityJobs.slice(0, 3).map(j => `<div class="border-b last:border-0 p-2 flex justify-between items-center"><div><b>${j.title}</b><br><span class="text-xs text-gray-500">${j.location}</span></div> <button onclick="setAppView('jobs')" class="text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded">Details</button></div>`).join('')}
                        </div>
                    </div>

                    <div class="space-y-6">
                        <div class="bg-white rounded-xl shadow-sm p-6">
                            <div class="flex justify-between items-center mb-4"><h3 class="font-bold text-lg text-green-600">Events</h3><button onclick="setAppView('events')" class="text-sm text-green-600 hover:underline">View All</button></div>
                            ${eventsData.localEvents.slice(0, 3).map(e => `<div class="border-b last:border-0 p-2"><b>${e.title}</b><br><span class="text-xs text-gray-500">${e.date}</span></div>`).join('')}
                        </div>
                        <div class="bg-white rounded-xl shadow-sm p-6"><h3 class="font-bold mb-2">Quick Access</h3><div class="grid grid-cols-2 gap-2"><button onclick="setAppView('directory')" class="p-2 bg-blue-50 text-blue-600 rounded text-sm">Directory</button><button onclick="setAppView('agent')" class="p-2 bg-gray-100 text-gray-700 rounded text-sm">RTK Agent</button></div></div>
                    </div>
                </div>

                <div class="bg-white rounded-xl shadow-sm p-6 mt-8">
                    <div class="flex justify-between items-center mb-6"><h2 class="text-2xl font-bold text-gray-800"><i class="fas fa-users text-purple-600 mr-2"></i> Community Forum</h2><button onclick="document.getElementById('post-form').classList.toggle('hidden')" class="bg-purple-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-purple-700"><i class="fas fa-plus mr-2"></i> Create Post</button></div>
                    <form id="post-form" onsubmit="handleCreatePost(event)" class="hidden mb-6 bg-gray-50 p-4 rounded-lg border"><textarea name="content" class="w-full p-3 border rounded-lg mb-2" placeholder="Share an update..." rows="3" required></textarea><div class="flex justify-end"><button type="submit" class="bg-purple-600 text-white px-4 py-2 rounded-lg font-bold">Post</button></div></form>
                    <div class="space-y-4">${renderForumList()}</div>
                </div>
            </div>
        </main>
        
        <nav class="sm:hidden fixed bottom-0 w-full bg-white border-t border-gray-200 flex justify-around py-3 z-50 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
            <button onclick="setAppView('dashboard')" class="flex flex-col items-center text-gray-600 hover:text-red-600"><i class="fas fa-home text-lg mb-1"></i><span class="text-[10px] font-medium">Home</span></button>
            <button onclick="setAppView('jobs')" class="flex flex-col items-center text-gray-600 hover:text-blue-600"><i class="fas fa-briefcase text-lg mb-1"></i><span class="text-[10px] font-medium">Jobs</span></button>
            <button onclick="setAppView('agent')" class="flex flex-col items-center text-gray-600 hover:text-purple-600"><div class="bg-purple-600 text-white w-10 h-10 rounded-full flex items-center justify-center -mt-6 shadow-lg border-4 border-white"><i class="fas fa-robot text-lg"></i></div></button>
            <button onclick="setAppView('events')" class="flex flex-col items-center text-gray-600 hover:text-green-600"><i class="fas fa-calendar-alt text-lg mb-1"></i><span class="text-[10px] font-medium">Events</span></button>
            <button onclick="setAppView('civic')" class="flex flex-col items-center text-gray-600 hover:text-red-600"><i class="fas fa-shield-alt text-lg mb-1"></i><span class="text-[10px] font-medium">Civic</span></button>
        </nav>
    </div>`;
}

function renderAuth() {
    const isLogin = state.authMode === 'login';
    return `
    <div class="h-full flex items-center justify-center bg-gradient-to-br from-gray-900 to-gray-800 p-4 fade-in overflow-y-auto">
        <div class="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden my-auto">
            <div class="p-8">
                <div class="text-center mb-8"><i class="fas fa-fingerprint text-5xl text-red-600 mb-2"></i><h1 class="text-2xl font-bold text-gray-800">Digital Citizen Hub</h1></div>
                ${state.authError ? `<div class="bg-red-100 text-red-700 p-3 rounded mb-4 text-sm text-center">${state.authError}</div>` : ''}
                <form id="auth-form" class="space-y-4">
                    ${!isLogin ? `<div><label class="text-sm font-medium">Full Name</label><input name="fullname" required class="w-full px-3 py-2 border rounded"></div><div><label class="text-sm font-medium">City</label><select name="city" class="w-full px-3 py-2 border rounded">${cityOptions}</select></div>` : ''}
                    <div><label class="text-sm font-medium">Email</label><input type="email" name="email" required class="w-full px-3 py-2 border rounded"></div>
                    <div><label class="text-sm font-medium">Password</label><input type="password" name="password" required class="w-full px-3 py-2 border rounded"></div>
                    <button type="submit" class="w-full py-3 bg-red-600 text-white font-bold rounded hover:bg-red-700">${state.isAuthLoading ? '...' : (isLogin ? 'Sign In' : 'Create Account')}</button>
                </form>
                <div class="mt-6 text-center text-sm"><button onclick="toggleAuthMode()" class="text-red-600 font-semibold hover:underline">${isLogin ? 'Sign Up' : 'Log In'}</button></div>
            </div>
        </div>
    </div>`;
}

// --- SCROLL PRESERVATION FIX ---
function render() {
    // 1. Capture scroll position
    const mainScrollContainer = document.getElementById('main-scroll-container');
    const previousScrollTop = mainScrollContainer ? mainScrollContainer.scrollTop : 0;

    if (!state.currentUser) {
        state.appContainer.innerHTML = renderAuth();
        const form = document.getElementById('auth-form');
        if (form) form.onsubmit = state.authMode === 'login' ? handleLogin : handleSignUp;
    } else {
        if (!state.userProfile) {
            state.appContainer.innerHTML = '<div class="h-full flex items-center justify-center"><i class="fas fa-spinner fa-spin text-2xl text-red-600"></i></div>';
            return;
        }
        if (state.currentView === 'dashboard') state.appContainer.innerHTML = renderDashboard();
        else if (state.currentView === 'agent') { state.appContainer.innerHTML = renderAgent(); const c = document.getElementById('chat-container'); if (c) c.scrollTop = c.scrollHeight; }
        else if (state.currentView === 'admin' && state.isAdmin) state.appContainer.innerHTML = renderAdmin();
        else if (state.currentView === 'directory') state.appContainer.innerHTML = renderDirectory();
        else if (state.currentView === 'jobs') state.appContainer.innerHTML = renderAllJobs();
        else if (state.currentView === 'events') state.appContainer.innerHTML = renderAllEvents();
        else if (state.currentView === 'civic') state.appContainer.innerHTML = renderCivicCenter();

        // 2. Restore scroll position
        const newScrollContainer = document.getElementById('main-scroll-container');
        if (newScrollContainer) {
            newScrollContainer.scrollTop = previousScrollTop;
        }
    }
}

// --- GLOBAL EXPORTS ---
window.toggleAuthMode = () => { state.authMode = state.authMode === 'login' ? 'signup' : 'login'; state.authError = ''; render(); };
window.handleSignOut = () => { signOut(auth); state.currentUser = null; render(); };
window.setAppView = (view) => { state.currentView = view; render(); };

window.revealContact = revealContact;
window.handleAgentSubmit = handleAgentSubmit;
window.handleAdminStatusUpdate = handleAdminStatusUpdate;
window.handleAdminAddJob = handleAdminAddJob;
window.handleCreatePost = handleCreatePost;
window.handleVote = handleVote;
window.handleFlag = handleFlag;
window.handleComment = handleComment;
window.handleDeletePost = handleDeletePost;
window.handleReinstatePost = handleReinstatePost;
window.fetchTrafficUpdate = fetchTrafficUpdate;
window.toggleUrgency = toggleUrgency;
window.loadAdminJobs = loadAdminJobs; 
window.handleAdminDeleteJob = handleAdminDeleteJob;
window.setEditingJob = setEditingJob;
window.clearEditingJob = clearEditingJob;
window.handleAdminEditJob = handleAdminEditJob;

window.handleCreateEvent = handleCreateEvent;
window.handleEditEvent = handleEditEvent;
window.handleDeleteEvent = handleDeleteEvent;
window.handleRsvp = handleRsvp;
window.setEditingEvent = setEditingEvent;
window.clearEditingEvent = clearEditingEvent;
window.setEditingEventAdmin = setEditingEventAdmin;
window.clearEditingEventAdmin = clearEditingEventAdmin;
window.handleAdminAddEvent = handleAdminAddEvent;
window.handleAdminEditEvent = handleAdminEditEvent;
window.handleAdminDeleteEvent = handleAdminDeleteEvent;

window.loadAdminUsers = loadAdminUsers;
window.setEditingUser = setEditingUser;
window.clearEditingUser = clearEditingUser;
window.handleAdminUpdateUser = handleAdminUpdateUser;
window.handleToggleVerifyUser = handleToggleVerifyUser;

window.handleCommentLike = handleCommentLike;
window.initReply = initReply;
window.cancelReply = cancelReply;

window.onload = initApp;